@echo off
:: ════════════════════════════════════════════════════════════════
::  SpanTag — Stop All Services
::  Kills all Java (Spring Boot) and Node (Vite) processes
:: ════════════════════════════════════════════════════════════════

echo.
echo [91m Stopping all SpanTag services... [0m
echo.

:: Kill all Java processes (Spring Boot services)
echo [96m Stopping Java services...[0m
taskkill /F /IM java.exe /T >nul 2>&1
if %errorlevel%==0 (
    echo [92m Java services stopped. [0m
) else (
    echo [90m No Java processes found. [0m
)

:: Kill Node.js processes (Vite frontend)
echo [96m Stopping Node/Vite frontend...[0m
taskkill /F /IM node.exe /T >nul 2>&1
if %errorlevel%==0 (
    echo [92m Frontend stopped. [0m
) else (
    echo [90m No Node processes found. [0m
)

echo.
echo [92m All SpanTag services stopped. [0m
echo.

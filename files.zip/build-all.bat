@echo off
:: ════════════════════════════════════════════════════════════════
::  SpanTag — Build All Services (mvn clean package -DskipTests)
::  Run this once after making code changes before starting
:: ════════════════════════════════════════════════════════════════

setlocal

set BASE=D:\keyclockbf
set MVN=mvn

echo.
echo [93m Building all SpanTag services... [0m
echo [90m (This may take a few minutes) [0m
echo.

set FAILED=0

call :build regularAuthentication
call :build userservice
call :build oauth2-service
call :build profile
call :build dashboard
call :build order-service
call :build payment-service
call :build Apigatewayapplication

echo.
if %FAILED%==0 (
    echo [92m All services built successfully! [0m
    echo [90m Now run start.bat to start all services. [0m
) else (
    echo [91m Some builds failed. Check the output above. [0m
)
echo.

endlocal
goto :eof

:build
set svc=%1
echo [96m Building %svc%...[0m
cd /d "%BASE%\%svc%"
call %MVN% clean package -DskipTests -q
if %errorlevel%==0 (
    echo [92m   ✓ %svc% built OK [0m
) else (
    echo [91m   ✗ %svc% BUILD FAILED [0m
    set FAILED=1
)
goto :eof

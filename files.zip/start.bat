@echo off
:: ════════════════════════════════════════════════════════════════
::  SpanTag — Start All Services
::  Run this from: D:\keyclockbf\
::  Prerequisites: MySQL running, Keycloak running on :8180
:: ════════════════════════════════════════════════════════════════

setlocal

:: ── Base directory (where all your service folders are) ─────────
set BASE=D:\keyclockbf

:: ── Maven command (use mvnw if no system Maven) ─────────────────
set MVN=mvn

:: ── Colors via ANSI (Windows 10+) ───────────────────────────────
echo.
echo [92m SpanTag Starting All Services [0m
echo [90m Base: %BASE% [0m
echo.

:: ── 1. regularAuthentication :9090 ──────────────────────────────
echo [96m[1/8] Starting regularAuthentication :9090...[0m
cd /d "%BASE%\regularAuthentication"
start "regularAuthentication" cmd /k "%MVN% spring-boot:run"
timeout /t 5 /nobreak >nul

:: ── 2. userservice :9091 ────────────────────────────────────────
echo [96m[2/8] Starting userservice :9091...[0m
cd /d "%BASE%\userservice"
start "userservice" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 3. oauth2-service :9092 ─────────────────────────────────────
echo [96m[3/8] Starting oauth2-service :9092...[0m
cd /d "%BASE%\oauth2-service"
start "oauth2-service" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 4. profile :9093 ────────────────────────────────────────────
echo [96m[4/8] Starting profile :9093...[0m
cd /d "%BASE%\profile"
start "profile" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 5. dashboard :9094 ──────────────────────────────────────────
echo [96m[5/8] Starting dashboard :9094...[0m
cd /d "%BASE%\dashboard"
start "dashboard" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 6. order-service :9095 ──────────────────────────────────────
echo [96m[6/8] Starting order-service :9095...[0m
cd /d "%BASE%\order-service"
start "order-service" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 7. payment-service :9096 ────────────────────────────────────
echo [96m[7/8] Starting payment-service :9096...[0m
cd /d "%BASE%\payment-service"
start "payment-service" cmd /k "%MVN% spring-boot:run"
timeout /t 3 /nobreak >nul

:: ── 8. API Gateway :1013 (last — depends on all others) ─────────
echo [96m[8/8] Starting API Gateway :1013...[0m
cd /d "%BASE%\Apigatewayapplication"
start "Apigatewayapplication" cmd /k "%MVN% spring-boot:run"
timeout /t 5 /nobreak >nul

:: ── 9. Frontend :5173 ───────────────────────────────────────────
echo [93m[9/9] Starting Frontend :5173...[0m
cd /d "%BASE%\fronted\fronted"
start "frontend" cmd /k "npm run dev"

echo.
echo [92m All services started! [0m
echo.
echo [90m Services:
echo   regularAuthentication  →  http://localhost:9090
echo   userservice            →  http://localhost:9091
echo   oauth2-service         →  http://localhost:9092
echo   profile                →  http://localhost:9093
echo   dashboard              →  http://localhost:9094
echo   order-service          →  http://localhost:9095
echo   payment-service        →  http://localhost:9096
echo   API Gateway            →  http://localhost:1013
echo   Frontend               →  http://localhost:5173  [0m
echo.
echo [93m Open your browser at: http://localhost:5173 [0m
echo.

endlocal

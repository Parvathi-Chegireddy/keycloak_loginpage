@echo off
:: ════════════════════════════════════════════════════════════════
::  SpanTag — Restart a Single Service
::  Usage: restart-service.bat <service-name>
::  Example: restart-service.bat payment-service
::           restart-service.bat Apigatewayapplication
::           restart-service.bat frontend
:: ════════════════════════════════════════════════════════════════

setlocal

set BASE=D:\keyclockbf
set MVN=mvn
set SERVICE=%1

if "%SERVICE%"=="" (
    echo [91m Usage: restart-service.bat ^<service-name^> [0m
    echo.
    echo [90m Available services:
    echo   regularAuthentication
    echo   userservice
    echo   oauth2-service
    echo   profile
    echo   dashboard
    echo   order-service
    echo   payment-service
    echo   Apigatewayapplication
    echo   frontend [0m
    goto :end
)

:: Find and kill the process running on the service's port
echo [93m Stopping %SERVICE%... [0m

if "%SERVICE%"=="regularAuthentication"  set PORT=9090
if "%SERVICE%"=="userservice"            set PORT=9091
if "%SERVICE%"=="oauth2-service"         set PORT=9092
if "%SERVICE%"=="profile"                set PORT=9093
if "%SERVICE%"=="dashboard"              set PORT=9094
if "%SERVICE%"=="order-service"          set PORT=9095
if "%SERVICE%"=="payment-service"        set PORT=9096
if "%SERVICE%"=="Apigatewayapplication"  set PORT=1013
if "%SERVICE%"=="frontend"               set PORT=5173

:: Kill process on that port
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
    echo [92m Killed process on port %PORT% (PID: %%a) [0m
)

timeout /t 2 /nobreak >nul

:: Start the service again
echo [96m Starting %SERVICE%... [0m

if "%SERVICE%"=="frontend" (
    cd /d "%BASE%\fronted\fronted"
    start "%SERVICE%" cmd /k "npm run dev"
) else (
    cd /d "%BASE%\%SERVICE%"
    start "%SERVICE%" cmd /k "%MVN% spring-boot:run"
)

echo [92m %SERVICE% restarted! [0m

:end
endlocal

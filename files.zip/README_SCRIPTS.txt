════════════════════════════════════════════════════════════════
  SpanTag — Script Usage Guide
════════════════════════════════════════════════════════════════

SETUP
─────
1. Copy all .bat files to: D:\keyclockbf\
2. That folder should look like:
     D:\keyclockbf\
       ├── start.bat                ← start all services
       ├── stop.bat                 ← stop all services
       ├── restart-service.bat      ← restart one service
       ├── status.bat               ← check which ports are open
       ├── build-all.bat            ← compile all services
       ├── regularAuthentication\
       ├── userservice\
       ├── oauth2-service\
       ├── profile\
       ├── dashboard\
       ├── order-service\
       ├── payment-service\
       ├── Apigatewayapplication\
       └── fronted\fronted\

DAILY USAGE
───────────
1. Start MySQL and Keycloak manually first

2. Check status:
   → Double-click status.bat
   → Keycloak (:8180) and MySQL (:3306) must be ✓ before starting

3. Start everything:
   → Double-click start.bat
   → 9 terminal windows will open (one per service)
   → Wait ~30 seconds for all to start
   → Open http://localhost:5173

4. Stop everything:
   → Double-click stop.bat

AFTER MAKING CODE CHANGES
──────────────────────────
Option A — Rebuild and restart one service:
   → restart-service.bat payment-service

Option B — Rebuild all then restart all:
   → Double-click build-all.bat   (compiles all)
   → Double-click stop.bat        (stop all)
   → Double-click start.bat       (start all)

STARTUP ORDER (automatic in start.bat)
───────────────────────────────────────
  1. MySQL :3306           ← start manually
  2. Keycloak :8180        ← start manually
  3. regularAuthentication :9090
  4. userservice           :9091
  5. oauth2-service        :9092
  6. profile               :9093
  7. dashboard             :9094
  8. order-service         :9095
  9. payment-service       :9096
  10. API Gateway          :1013  ← must start LAST
  11. Frontend             :5173

TROUBLESHOOTING
───────────────
• "Port already in use" → run stop.bat first, then start.bat
• Service not starting  → check the terminal window for that service
• Maven not found       → install Maven and add to PATH, or change
                          MVN=mvn to MVN=mvnw in the .bat files
════════════════════════════════════════════════════════════════

@echo off
:: ════════════════════════════════════════════════════════════════
::  SpanTag — Check Status of All Services
::  Shows which ports are listening
:: ════════════════════════════════════════════════════════════════

echo.
echo [96m SpanTag Service Status [0m
echo ════════════════════════════════════════
echo.

call :check 9090 "regularAuthentication"
call :check 9091 "userservice"
call :check 9092 "oauth2-service"
call :check 9093 "profile"
call :check 9094 "dashboard"
call :check 9095 "order-service"
call :check 9096 "payment-service"
call :check 1013 "API Gateway"
call :check 5173 "Frontend (Vite)"
call :check 8180 "Keycloak"
call :check 3306 "MySQL"

echo.
goto :eof

:check
set port=%1
set name=%~2
netstat -ano | findstr ":%port% " | findstr "LISTENING" >nul 2>&1
if %errorlevel%==0 (
    echo [92m  ✓  :%port%  %name% [0m
) else (
    echo [91m  ✗  :%port%  %name%  [NOT RUNNING] [0m
)
goto :eof
